BookofCaspi for Windows
1. Extract this whole folder (right-click the zip, "Extract All").
2. Right-click install.ps1 and choose "Run with PowerShell".
   If Windows blocks it, open PowerShell in this folder and run:
   powershell -ExecutionPolicy Bypass -File .\install.ps1
3. BookofCaspi opens, and it is in your Start menu.
